
import 'package:flutter/material.dart';
import 'stock_manager.dart';

class SellerDashboard extends StatelessWidget {
  const SellerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Painel do Lojista")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: const Text("Gerenciar Estoque"),
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder:_=>const StockManager()));
              },
            )
          ],
        ),
      ),
    );
  }
}
