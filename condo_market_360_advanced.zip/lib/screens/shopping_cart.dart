
import 'package:flutter/material.dart';

class ShoppingCart extends StatefulWidget {
  static List items = [];

  const ShoppingCart({super.key});

  @override
  State<ShoppingCart> createState() => _ShoppingCartState();
}

class _ShoppingCartState extends State<ShoppingCart> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Carrinho")),
      body: ListView.builder(
        itemCount: ShoppingCart.items.length,
        itemBuilder: (c,i){
          final item = ShoppingCart.items[i];
          return ListTile(
            title: Text(item['name']),
            subtitle: Text("R\$ ${item['price']}"),
            trailing: IconButton(
              icon: const Icon(Icons.remove),
              onPressed: (){
                setState(()=>ShoppingCart.items.removeAt(i));
              },
            ),
          );
        }
      ),
    );
  }
}
