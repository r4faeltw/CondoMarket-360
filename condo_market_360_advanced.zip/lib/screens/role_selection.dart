
import 'package:flutter/material.dart';
import 'login.dart';
import 'purchase_screen.dart';
import 'seller_dashboard.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Condo Market 360")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: const Text("Entrar como Cliente"),
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LoginScreen(isSeller:false))),
            ),
            ElevatedButton(
              child: const Text("Entrar como Lojista"),
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LoginScreen(isSeller:true))),
            ),
          ],
        ),
      ),
    );
  }
}
