
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'purchase_screen.dart';
import 'seller_dashboard.dart';

class LoginScreen extends StatefulWidget {
  final bool isSeller;
  const LoginScreen({super.key, required this.isSeller});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  bool loading=false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.isSeller?"Login Lojista":"Login Cliente")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(controller: emailCtrl, decoration: const InputDecoration(labelText:"Email")),
            TextField(controller: passCtrl, decoration: const InputDecoration(labelText:"Senha"), obscureText: true),
            const SizedBox(height:20),
            ElevatedButton(
              child: loading?CircularProgressIndicator():const Text("Entrar"),
              onPressed: () async {
                setState(()=>loading=true);
                await AuthService.login(emailCtrl.text, passCtrl.text);
                setState(()=>loading=false);
                Navigator.push(context, MaterialPageRoute(
                  builder:_=> widget.isSeller? const SellerDashboard(): const PurchaseScreen()
                ));
              },
            ),
          ],
        ),
      ),
    );
  }
}
