
import 'package:flutter/material.dart';
import '../services/db_service.dart';
import 'shopping_cart.dart';

class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({super.key});

  @override
  State<PurchaseScreen> createState() => _PurchaseScreenState();
}

class _PurchaseScreenState extends State<PurchaseScreen> {
  List products=[];

  @override
  void initState() {
    super.initState();
    load();
  }

  void load() async {
    products = await DBService.getProducts();
    setState((){});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Comprar"),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: ()=>Navigator.push(context, MaterialPageRoute(builder:_=>const ShoppingCart())),
          )
        ],
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder:(c,i){
          final p = products[i];
          return ListTile(
            title: Text(p['name']),
            subtitle: Text("R\$ ${p['price']} | Estoque: ${p['stock']}"),
            trailing: IconButton(
              icon: const Icon(Icons.add),
              onPressed: ()=> ShoppingCart.items.add(p),
            ),
          );
        }
      ),
    );
  }
}
