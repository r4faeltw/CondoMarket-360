
import 'package:flutter/material.dart';
import '../services/db_service.dart';
import 'item_form.dart';

class StockManager extends StatefulWidget {
  const StockManager({super.key});

  @override
  State<StockManager> createState() => _StockManagerState();
}

class _StockManagerState extends State<StockManager> {
  List items=[];

  @override
  void initState() {
    super.initState();
    load();
  }

  load() async {
    items = await DBService.getProducts();
    setState((){});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Estoque")),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          final item = await Navigator.push(context, MaterialPageRoute(builder:_=>const ItemForm()));
          if(item!=null){
            await DBService.addProduct(item);
            load();
          }
        },
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder:(c,i){
          final item = items[i];
          return ListTile(
            title: Text(item['name']),
            subtitle: Text("Estoque: ${item['stock']}"),
          );
        }
      ),
    );
  }
}
