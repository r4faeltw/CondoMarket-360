
import 'package:flutter/material.dart';

class ItemForm extends StatefulWidget {
  const ItemForm({super.key});

  @override
  State<ItemForm> createState() => _ItemFormState();
}

class _ItemFormState extends State<ItemForm> {
  final nameCtrl=TextEditingController();
  final stockCtrl=TextEditingController();
  final priceCtrl=TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Cadastrar Produto")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText:"Nome")),
            TextField(controller: priceCtrl, decoration: const InputDecoration(labelText:"Preço")),
            TextField(controller: stockCtrl, decoration: const InputDecoration(labelText:"Estoque Inicial")),
            ElevatedButton(
              child: const Text("Salvar"),
              onPressed: (){
                Navigator.pop(context,{
                  "name":nameCtrl.text,
                  "price":double.tryParse(priceCtrl.text)??0,
                  "stock":int.tryParse(stockCtrl.text)??0,
                });
              },
            )
          ],
        ),
      ),
    );
  }
}
