
class AuthService {
  static Future<void> login(String email, String pass) async {
    // Placeholder Firebase login logic
    await Future.delayed(const Duration(milliseconds:700));
  }
}
