
class DBService {
  static List products = [];

  static Future<List> getProducts() async {
    await Future.delayed(const Duration(milliseconds:400));
    return products;
  }

  static Future<void> addProduct(Map item) async {
    products.add(item);
  }
}
